Keep the latest task notes.
