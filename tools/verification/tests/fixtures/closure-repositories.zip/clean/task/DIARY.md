Accepted project source and verification.
