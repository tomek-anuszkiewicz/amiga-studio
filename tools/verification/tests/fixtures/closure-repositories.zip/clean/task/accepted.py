def accepted_closure_symbol():
    return True
