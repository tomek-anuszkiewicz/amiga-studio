Initial task notes.
