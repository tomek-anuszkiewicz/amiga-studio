The accepted terminology includes deinstrumentation.
