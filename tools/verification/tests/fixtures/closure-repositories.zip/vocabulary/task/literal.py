rejected = 'deliberatebadliteral'
