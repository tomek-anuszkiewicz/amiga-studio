The task is suposed to succeed.
