Maintain ordinary task notes.
